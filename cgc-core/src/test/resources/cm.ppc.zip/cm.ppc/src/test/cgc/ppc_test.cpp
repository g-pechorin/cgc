
#include "gtest/gtest.h"

#include <ppc.hpp>

TEST(ppc_test, turn_on)
{
	ppc::context ppc;
}

TEST(ppc_test, bind)
{
	ppc::context ppc;

	ppc["foo"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		return ppc.value_error(0, "this shouldn't be called");
	};
}


TEST(ppc_test, call)
{
	ppc::context ppc;

	static bool called_foo = false;
	static bool called_foe = false;
	static bool called_bar = false;

	ppc["foo"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		called_foo = true;
		return ppc.value_nil();
	};

	ppc["foe"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		called_foe = true;
		return ppc.value_nil();
	};

	ppc["bar"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		called_bar = true;
		return ppc.value_nil();
	};

	ppc.invoke("(foo)");

	ASSERT_TRUE(called_foo);
	ASSERT_FALSE(called_foe);
	ASSERT_FALSE(called_bar);
}


TEST(ppc_test, call_arg)
{
	ppc::context ppc;

	static bool called_foo = false;
	static bool called_foe = false;
	static bool called_bar = false;

	static char* error_foo = nullptr;

	ppc["foo"] = [](ppc::context& ppc, const size_t l, const ppc::value_p*a) ->ppc::value_p
	{
		called_foo = true;

		if (l != 1)
			error_foo = "wrong number of args";
		else if (!a[0]->is<ppc::value_s::kind_e::NIL>())
			error_foo = "non-nil arg";

		return ppc.value_nil();
	};

	ppc["foe"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		called_foe = true;
		return ppc.value_nil();
	};

	ppc["bar"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		called_bar = true;
		return ppc.value_nil();
	};

	ppc.invoke("(foo ())");

	ASSERT_TRUE(called_foo);
	ASSERT_FALSE(called_foe);
	ASSERT_FALSE(called_bar);


	if (error_foo)
		FAIL() << error_foo;
}


TEST(ppc_test, call_symbol)
{
	ppc::context ppc;

	static bool foo_call = false;
	static bool bar_call = false;

	static char* error_foo = nullptr;

	ppc["foo"] = [](ppc::context& ppc, const size_t l, const ppc::value_p*a) ->ppc::value_p
	{

		if (l != 2)
			error_foo = "wrong number of args";
		else if (!a[0]->is<ppc::value_s::kind_e::SYMBOL>())
			error_foo = "arg:0 should be a SYMBOL";
		else if (!a[0]->strequal("bar"))
			error_foo = "arg:0 should be `bar";
		else if (!a[1]->is<ppc::value_s::kind_e::DOUBLE>())
			error_foo = "arg:1 should be a DOUBLE";
		else if (3.14 != a[1]->number())
			error_foo = "arg:1 should be 3.14";
		else
			foo_call = true;

		return ppc.value_nil();
	};

	ppc["bar"] = [](ppc::context& ppc, const size_t, const ppc::value_p*) ->ppc::value_p
	{
		bar_call = true;
		return ppc.value_nil();
	};

	ppc.invoke("(foo `bar 3.14)");

	if (error_foo)
		FAIL() << error_foo;

	ASSERT_TRUE(foo_call);
	ASSERT_FALSE(bar_call);
	
}
