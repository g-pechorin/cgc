#define ppc_cpp
#include <ppc.hpp>

#include <stack>
#include <vector>

ppc_cpp size_t ppc::context::_count_alphanum(const char* str)
{
	const auto c = *str;
	if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('1' <= c && c <= '9') || '0' == c || '-' == c)
		return 1 + ppc::context::_count_alphanum(1 + str);

	return 0;
}

ppc_cpp char ppc::context::_skipover(const size_t length, const char* source, size_t& next, const char* skip)
{
restart:
	if (length <= next)
		return '\0';

	// check each skip char
	for (size_t what = 0; skip[what]; ++what)
		// compare it to the next char
		if (skip[what] == source[next])
		{
			// skip in a non-recursive way
			next += 1;
			goto restart;
		}

	assert(source[next] && "Don't put \\0 in your scripts clown!");

	return source[next];
}

ppc_cpp ppc::context::~context(void)
{
}

ppc_cpp ppc::context::bindcall::bindcall(ppc::context* self, const char* name, void* data) :
	_self(self),
	_name(name),
	_data(data)
{
}

ppc_cpp void ppc::context::bindcall::operator=(ppc::callback_f code)
{
	_self->bindusercall(_name, _data, code, [](ppc::context&, void*) {});
}

ppc_cpp void ppc::context::bindcall::operator=(ppc::release_f dead)
{
	_self->bindusercall(_name, _data, [](ppc::context& ppc, void*, uint16_t, const value_p*) ->value_p {
		return ppc.value_error(0, "this is not invokable");
	}, dead);
}

ppc_cpp ppc::context::binddata::binddata(ppc::context* self, const char* name) :
	_self(self),
	_name(name)
{
}

ppc_cpp ppc::context::bindcall ppc::context::binddata::operator[](void* data)
{
	assert(data);
	return ppc::context::bindcall(_self, _name, data);
}

ppc_cpp void ppc::context::binddata::operator=(ppc::function_f code)
{
	_self->bindfunction(_name, code);
}

ppc_cpp void ppc::context::bindfunction(const char* name, function_f code)
{
	auto r = std::make_shared<ppc::value_s>();

	r->_context = this;
	r->_kind = ppc::value_s::kind_e::FUNCTION;
	r->_data._user = code;

	_registry[ppc_name(name)] = r;
}

ppc_cpp void ppc::context::bindusercall(const char* name, void* data, ppc::callback_f code, ppc::release_f dead)
{
	if (nullptr != data)
		assert(nullptr != data && "need a real pointer for the codetable to work right");

	auto r = std::make_shared<ppc::value_s>();

	r->_context = this;
	r->_kind = ppc::value_s::kind_e::OBJECT;
	r->_data._user = data;

	// ensure we're not duplicating something
	assert((nullptr == data) || (_codetable.end() == _codetable.find(data)) && "rebinding!");

	// store the bits
	_codetable[data]._code = code;
	_codetable[data]._dead = dead;

	// put the value global
	const ppc_name key = name;
	_registry[key] = r;
}

ppc_cpp ppc::context::context(void)
{
}

ppc_cpp void ppc::context::invoke(const char* code)
{
	return invoke(strlen(code), code);
}

ppc_cpp void ppc::context::invoke(const size_t length, const char* source)
{

	struct script_frame
	{
		std::vector<ppc::value_p> _locals;
		size_t _start;
	};

	std::stack<script_frame> stack;

	size_t next = 0;
	char c;
	while (c = ppc::context::_skipover(length, source, next, "\n\r\t "))
	{
		switch (c)
		{
		case '(':
			stack.emplace();
			stack.top()._start = next;
			break;

		case ')':
		{
			ppc::value_p r;

			if (0 == stack.top()._locals.size()) // handle `()`
				r = value_nil();
			else
			{
				// execute the code at the top
				auto code = stack.top()._locals.front();
				if (code->is<ppc::value_s::kind_e::FUNCTION>())
				{
					r = reinterpret_cast<ppc::function_f>(code->_data._user)(*this, stack.top()._locals.size() - 1, stack.top()._locals.data() + 1);
				}
				else if (code->is<ppc::value_s::kind_e::OBJECT>())
				{
					STUB("execute from object");
				}
				else
				{
					r = value_error(stack.top()._start, "that wasn't executable");
				}
			}

			// pop the top and pushpend that value
			stack.pop();
			if (!stack.empty())
				stack.top()._locals.push_back(r);
		}
		break;

		// symbols
		case '`':
		{
			const size_t size = ppc::context::_count_alphanum(source + next + 1);

			// pushpend the symbol
			stack.top()._locals.push_back(
				value_symbol(size, source + next + 1)
			);

			next += size;
		}
		break;


		default:
			if (('0' <= c && c <= '9') || '+' == c || '-' == c || '.' == c)
			{
				const auto head = source + next;

				size_t tail = 0;
				if ('+' == c || '-' == c)
					STUB("handle the sign symbol");

				while ((c = head[tail]) && ('0' <= c && c <= '9'))
					++tail;

				if ('.' != c)
					STUB("handle the integral");
				else
				{
					++tail;
					while ((c = head[tail]) && ('0' <= c && c <= '9'))
						++tail;

					char text[64];
					((char*)memcpy(text, head, tail))[tail] = '\0';

					double value;
					sscanf(text, "%lf", &value);

					// pushpend that value into the top script frame
					stack.top()._locals.push_back(value_double(value));

					next = (next + tail - 1);
					break;
				}
			}

			if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z'))
			{
				const size_t size = ppc::context::_count_alphanum(source + next);

				const ppc_name key = ppc_name(source + next, size);

				// check for missing key
				ppc::value_p val;
				if (_registry.end() == _registry.find(key))
				{
					// oops!
					val = value_error(next, "unbound name");
				}
				else
				{
					// read a value from the global registry (or whatnot)
					val = _registry[key];
				}

				// pushpend that value into the top script frame
				stack.top()._locals.push_back(val);

				// move on
				next += size;
				next -= 1;
				break;
			}

			STUB("TODO ; implement a general error shenanigan");
		}
		++next;
	}
}

ppc_cpp ppc::context::binddata ppc::context::operator[](const char* name)
{
	return ppc::context::binddata(this, name);
}

ppc_cpp ppc::value_p ppc::context::value_double(const double value)
{
	auto r = std::make_shared<ppc::value_s>();

	r->_context = this;
	r->_kind = ppc::value_s::kind_e::DOUBLE;
	r->_data._double = value;

	return r;
}

ppc_cpp ppc::value_p ppc::context::value_error(const size_t offset, const char* message)
{
	auto r = std::make_shared<ppc::value_s>();

	r->_context = this;
	r->_kind = ppc::value_s::kind_e::ERROR;
	r->_data._text = value_symbol(message)->text();
	r->_meta._offset = offset;

	return r;
}

ppc_cpp ppc::value_p ppc::context::value_nil(void)
{
	ppc::value_p r = std::make_shared<ppc::value_s>();

	r->_context = this;
	r->_kind = ppc::value_s::kind_e::NIL;

	return r;
}

ppc_cpp ppc::value_p ppc::context::value_symbol(const char* symbol)
{
	return value_symbol(strlen(symbol), symbol);
}

ppc_cpp ppc::value_p ppc::context::value_symbol(size_t len, const char* str)
{
	const ppc_name key = ppc_name(str, len);

	const uint32_t hash = pal::adler()(len, str);

	if (_interned.end() == _interned.find(hash))
		_interned[hash] = ppc_text(str, len);

	ppc::value_p r = std::make_shared<ppc::value_s>();

	r->_context = this;
	r->_kind = ppc::value_s::kind_e::SYMBOL;
	r->_data._text = _interned[hash].c_str();
	r->_meta._hash = hash;

	return r;
}

ppc_cpp ppc::value_s::~value_s(void)
{
	if (ppc::value_s::kind_e::OBJECT == _kind)
	{
		assert(nullptr != _data._user);

		// run the GC'er
		_context->_codetable[_data._user]._dead(*_context, _data._user);

		// erase the entry
		_context->_codetable.erase(_data._user);
	}
}

ppc_cpp double ppc::value_s::number(void) const
{
	assert(is<ppc::value_s::kind_e::DOUBLE>());

	return _data._double;
}

ppc_cpp bool ppc::value_s::strequal(const char* text) const
{
	assert(is<ppc::value_s::kind_e::SYMBOL>());

	return 0 == strcmp(text, _data._text);
}

ppc_cpp const char* ppc::value_s::text(void) const
{
	assert(
		(ppc::value_s::kind_e::ERROR == _kind)
		|| (ppc::value_s::kind_e::SYMBOL == _kind)
	);

	return _data._text;
}
