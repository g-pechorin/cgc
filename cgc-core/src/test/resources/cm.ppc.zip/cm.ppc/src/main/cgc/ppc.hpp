
#pragma once

#include <string.h>

#include <functional>
#include <map>
#include <memory>

#include <pal.hpp>

// #define ppc_cpp inline
// #define ppc_cpp static


#ifndef ppc_text
#	include <string>
#	define ppc_text std::string
#endif

#ifndef ppc_name
#	define ppc_name ppc_text
#endif

#ifdef real16_t
#	define real16_m(A)	A
#else
#	define real16_m(A)	
#endif


namespace ppc
{
	struct context;
	struct value_s;

	struct value_s
	{
		friend struct context;

		enum class kind_e
		{
			SYMBOL,
			ERROR,
			NIL,
			DOUBLE,
			OBJECT,
			FUNCTION,
		};

		template<kind_e>
		bool is(void) const;

		~value_s(void);

		bool strequal(const char*)const;
		double number(void)const;
		const char* text(void) const;

	private:
		context* _context;

		kind_e _kind;

		union {
			const char* _text;
			void* _user;
			double _double;
		} _data;

		union {
			size_t _offset;
			uint32_t _hash;
		} _meta;
	};

	typedef std::shared_ptr<value_s> value_p;

	typedef std::function<value_p(ppc::context&, void*, uint16_t, const value_p*)> callback_f;
	typedef std::function<void(ppc::context&, void*)> release_f;
	typedef value_p(*function_f)(context&, const size_t, const value_p*);

	struct context
	{
		friend struct value_s;

		void bindusercall(const char*, void*, callback_f, release_f);

		void bindfunction(const char*, function_f);

		class bindcall
		{
			context* _self;
			const char* _name;
			void* _data;
		public:
			void operator=(callback_f code);

			void operator=(release_f code);

			void operator()(callback_f, release_f);

			bindcall(context*, const char*, void*);
		};

		class binddata
		{
			context* _self;
			const char* _name;
		public:
			bindcall operator[](void*);

			binddata(context*, const char*);

			void operator=(function_f);
		};

		binddata operator[](const char*);


		value_p value_double(const double);
		value_p value_error(size_t, const char*);
		value_p value_nil(void);

		/// intern or access a new string
		value_p value_symbol(size_t, const char*);
		value_p value_symbol(const char*);

		/// invoke script
		void invoke(const size_t, const char*);
		void invoke(const char*);

		context(void);

		context(const context&) = delete;
		context& operator=(const context&) = delete;

		~context(void);
	private:

		struct userdata
		{
			callback_f _code;
			release_f _dead;
		};


		std::map<uint32_t, ppc_text> _interned;
		std::map<ppc_name, value_p> _registry;
		std::map<void*, userdata> _codetable;

		/// skip in source until you hit a char we care
		static char _skipover(const size_t, const char*, size_t&, const char*);

		static size_t _count_alphanum(const char*);
	};
};

template<ppc::value_s::kind_e kind>
inline bool ppc::value_s::is(void) const
{
	return kind == _kind;
}

